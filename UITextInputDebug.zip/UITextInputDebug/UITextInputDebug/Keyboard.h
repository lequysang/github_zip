//
//  Keyboard.h
//  UITextInputDebug
//

#import <UIKit/UIKit.h>

@interface Keyboard : UIView
@property (strong,nonatomic) id<UITextInput> textInput;
-(void)setTextInput:(id<UITextInput>)textInput;

- (IBAction)charPress:(UIButton *)sender;
- (IBAction)repLace:(id)sender;

@end
