//
//  ViewController.h
//  UITextInputDebug
//


#import <UIKit/UIKit.h>
#import "Keyboard.h"

@interface ViewController : UIViewController<UITextFieldDelegate,UITextViewDelegate>
@property (weak, nonatomic) IBOutlet UITextField *textField;
@property (weak, nonatomic) IBOutlet UITextView *textView;

@property (strong,nonatomic) Keyboard *keyBoard;

@end
