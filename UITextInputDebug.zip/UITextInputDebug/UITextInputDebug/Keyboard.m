//
//  Keyboard.m
//  UITextInputDebug
//


#import "Keyboard.h"

@implementation Keyboard

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        // Initialization code
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"Keyboard" owner:self options:nil];
		[[nib objectAtIndex:0] setFrame:frame];
        self = [nib objectAtIndex:0];

    }
    return self;
}

- (id)init
{
    self = [super init];
    if (self) {
        // Initialization code
        // Initialization code
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"Keyboard" owner:self options:nil];
//		[[nib objectAtIndex:0] setFrame:frame];
        self = [nib objectAtIndex:0];
        
    }
    return self;
}


-(void)setTextInput:(id<UITextInput>)textInput{
    _textInput = textInput;
	if ([textInput isKindOfClass:[UITextView class]])
        [(UITextView *)textInput setInputView:self];
    else if ([textInput isKindOfClass:[UITextField class]])
        [(UITextField *)textInput setInputView:self];
}

- (IBAction)charPress:(UIButton *)sender {
    [self.textInput insertText:sender.titleLabel.text];
}

- (IBAction)repLace:(id)sender {
    //replace  char from positon 4(back) to T
    //Don't know how to do here with UITextRang;
    UITextRange *aRang;
    [self.textInput replaceRange:aRang withText:@"T"];
    
}

@end
