//
//  ViewController.m
//  UITextInputDebug
//


#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.keyBoard = [[Keyboard alloc] init];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    [self.keyBoard setTextInput:textField];
    return YES;
}
- (BOOL)textViewShouldBeginEditing:(UITextView *)textView{
    [self.keyBoard setTextInput:textView];
    return YES;
}

@end
