//
//  ViewController.m
//  CustomViewKVO
//
//  Created by Sang Quý Lê on 3/29/13.
//  Copyright (c) 2013 lequysang. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    CustomView *customView = [[CustomView alloc] init];
    customView.center = self.view.center;
    [self.view addSubview:customView];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
