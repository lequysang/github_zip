//
//  CustomView.h
//  CustomViewKVO
//
//  Created by Sang Quý Lê on 3/29/13.
//  Copyright (c) 2013 lequysang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomView : UIView
@property (nonatomic) NSInteger inputStateControl;

- (IBAction)changeState:(id)sender;

@end
