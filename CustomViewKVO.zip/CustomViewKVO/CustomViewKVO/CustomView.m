//
//  CustomView.m
//  CustomViewKVO
//
//  Created by Sang Quý Lê on 3/29/13.
//  Copyright (c) 2013 lequysang. All rights reserved.
//

#import "CustomView.h"
static void *kInputStateControlObservingContext = &kInputStateControlObservingContext;

@implementation CustomView

- (id)init
{
    self = [super init];
    if (self) {
        // Initialization code
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"CustomView" owner:self options:nil];
        self = [nib objectAtIndex:0];
        self.inputStateControl = 0;
        //
        [self commonInit];
    }
    return self;
}
-(void)commonInit{
    [self addObserver:self forKeyPath:@"inputStateControl" options:NSKeyValueObservingOptionOld context:kInputStateControlObservingContext];
}

#pragma mark Observer
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context {
    
    if ( context == kInputStateControlObservingContext ) {
        NSInteger oldState = [[change objectForKey:NSKeyValueChangeOldKey] integerValue];
        if ( oldState != self.inputStateControl ) {
            NSLog(@"CONTEXT change %i to %i",oldState,self.inputStateControl);
        }
    }
    else {
        [super observeValueForKeyPath:keyPath ofObject:object change:change context:context];
    }
}

-(void)dealloc{
//    [self removeObserver:self forKeyPath:@"inputStateControl"];
//    [self removeObserver:self forKeyPath:@"inputStateControl" context:kInputStateControlObservingContext];
}

- (IBAction)changeState:(id)sender {
    self.inputStateControl ++;
}

@end
