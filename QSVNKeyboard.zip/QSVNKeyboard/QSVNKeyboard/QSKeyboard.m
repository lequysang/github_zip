//
//  QSKeyboard.m
//  QSVNKeyboard
//
//  Created by Quy Sang Le on 2/18/13.
//  Copyright (c) 2013 Quy Sang Le. All rights reserved.
//

#import "QSKeyboard.h"

@implementation QSKeyboard



- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"QSKeyboard" owner:self options:nil];
		[[nib objectAtIndex:0] setFrame:frame];
        self = [nib objectAtIndex:0];
        self.currentWordArray = [[NSMutableArray alloc] initWithObjects:@"",@"",@"", nil];
//        NSLog(@"%@",self.currentWordArray);
        self.currentWord = [[NSString alloc] init];
        isClick = NO;
    }
    return self;
}

-(void)setTextView:(id<UITextInput>)textView{
    _textView = textView;
	if ([textView isKindOfClass:[UITextView class]])
        [(UITextView *)textView setInputView:self];
    else if ([textView isKindOfClass:[UITextField class]])
        [(UITextField *)textView setInputView:self];
}



- (IBAction)keysPress:(UIButton *)sender{
    [self.currentWordArray replaceObjectAtIndex:sender.tag withObject:sender.currentTitle];
    if (!isClick) {
        isClick = YES;
        [self performSelector:@selector(joinWord) withObject:nil afterDelay:0.05];
    }
}

- (IBAction)copyToClipboard:(id)sender {
    UITextView *textView = (UITextView*)self.textView;
    [UIPasteboard generalPasteboard].string = textView.text;
}

-(void)joinWord{
    self.currentWord = [NSString stringWithFormat:@"%@%@%@",[self.currentWordArray objectAtIndex:0],[self.currentWordArray objectAtIndex:1],[self.currentWordArray objectAtIndex:2] ];
    NSLog(@"%@",self.currentWord);
    [self.textView insertText:self.currentWord];
    isClick = NO;
    for (NSInteger i =0 ; i < [self.currentWordArray count];  i++) {
        [self.currentWordArray replaceObjectAtIndex:i withObject:@""];
    }
}

@end
