//
//  ViewController.h
//  QSVNKeyboard
//
//  Created by Quy Sang Le on 2/18/13.
//  Copyright (c) 2013 Quy Sang Le. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "QSKeyboard.h"
#import <QuartzCore/QuartzCore.h>

@interface ViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextView *textView;

@end
