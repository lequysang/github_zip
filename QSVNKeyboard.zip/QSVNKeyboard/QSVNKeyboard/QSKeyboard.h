//
//  QSKeyboard.h
//  QSVNKeyboard
//
//  Created by Quy Sang Le on 2/18/13.
//  Copyright (c) 2013 Quy Sang Le. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QSKeyboard : UIView{
    BOOL isClick;
}

@property(strong,nonatomic) NSString *currentWord;
@property(strong,nonatomic) NSMutableArray *currentWordArray;
@property (strong,nonatomic) id<UITextInput> textView;

- (IBAction)keysPress:(UIButton *)sender;
- (IBAction)copyToClipboard:(id)sender;
@property (strong, nonatomic) IBOutletCollection(UIButton) NSArray *buttons;
@property (weak, nonatomic) IBOutlet UIButton *testButton;

-(void)setTextView:(id<UITextInput>)textView;
@end
