//
//  ViewController.m
//  QSVNKeyboard
//
//  Created by Quy Sang Le on 2/18/13.
//  Copyright (c) 2013 Quy Sang Le. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    QSKeyboard *keyBoard = [[QSKeyboard alloc] initWithFrame:CGRectMake(0, 80, 320, 400)];
//    [self.view addSubview:keyBoard];
//    [self.textView setInputView:keyBoard];
    [keyBoard setTextView:self.textView];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidUnload {
    [self setTextView:nil];
    [super viewDidUnload];
}

-(BOOL)shouldAutorotate
{
    return NO;
}

@end
