//
//  QSKey.m
//  TestTouchOnView
//
//  Created by Quy Sang Le on 2/19/13.
//  Copyright (c) 2013 Quy Sang Le. All rights reserved.
//

#import "QSKey.h"

@implementation QSKey

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        NSLog(@"INIT");
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"QSKey" owner:self options:nil];
		[[nib objectAtIndex:0] setFrame:frame];
        self = [nib objectAtIndex:0];
    }
    return self;
}

-(void)awakeFromNib{
    NSLog(@"awakeFromNib");
}
- (id)initWithCoder:(NSCoder *)aDecoder{
    if (self = [super initWithCoder:aDecoder]) {
        NSLog(@"Coder");
        NSArray *subviewArray = [[NSBundle mainBundle] loadNibNamed:NSStringFromClass([self class]) owner:self options:nil];

        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"QSKey" owner:nil options:nil];
		[[nib objectAtIndex:0] setFrame:self.bounds];
        [self addSubview:[nib objectAtIndex:0]];
    }
    return self;
}


@end
