//
//  ViewController.m
//  TestTouchOnView
//
//  Created by Quy Sang Le on 2/19/13.
//  Copyright (c) 2013 Quy Sang Le. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib
//    QSKey *thKey = [[QSKey alloc] initWithFrame:CGRectMake(40, 250, 100, 100)];
//    
//    [self.view addSubview:thKey];
    
    for (QSKey *aView in self.view.subviews) {
        [self addGestureRecognizersToPiece:aView];
    }
}

- (void) viewDidAppear:(BOOL)animated{
//    for (QSKey *aView in self.view.subviews) {
//        [self addGestureRecognizersToPiece:aView];
//    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)addGestureRecognizersToPiece:(UIView *)piece
{
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapPiece:)];
    [piece addGestureRecognizer:tapGesture];
}

- (void)tapPiece:(UITapGestureRecognizer *)gestureRecognizer
{
    CGPoint tapPoint = [gestureRecognizer locationInView:self.view];
    QSKey *hitView = (QSKey *)[self.view hitTest:tapPoint withEvent:nil];
    if (hitView.superview == self.view) NSLog(@"%@",hitView);
    
}

@end
