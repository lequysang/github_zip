//
//  ThirdViewController.m
//  fullTabBaseApp
//
//  Created by Sang Quý Lê on 6/8/13.
//  Copyright (c) 2013 lequysang.com. All rights reserved.
//

#import "ThirdViewController.h"

@interface ThirdViewController ()

@end

@implementation ThirdViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = NSLocalizedString(@"Third", @"Third");
        self.tabBarItem.image = [UIImage imageNamed:@"first"];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

-(NSUInteger)supportedInterfaceOrientations
{
    return UIInterfaceOrientationMaskAllButUpsideDown;
}

-(BOOL)shouldAutorotate
{
    return YES;
}


- (IBAction)pushNEXT:(id)sender {
    NextOfThirdViewController *nextVC = [[NextOfThirdViewController alloc] initWithNibName:@"NextOfThirdViewController" bundle:nil];
    [(AppDelegate *)[[UIApplication sharedApplication] delegate] performSelector:@selector(reloadTabBarController) withObject:nil afterDelay:0.0];

    [self.navigationController pushViewController:nextVC animated:NO];
}

@end
