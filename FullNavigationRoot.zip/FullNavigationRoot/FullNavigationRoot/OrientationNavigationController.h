//
//  OrientationNavigationController.h
//  eskeysiphone
//
//  Created by Sang Quý Lê on 4/23/13.
//  Copyright (c) 2013 lequysang.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OrientationNavigationController : UINavigationController
@property(nonatomic, assign) UIInterfaceOrientation orientation;
@property(nonatomic, assign) NSUInteger supportedInterfaceOrientatoin;

@end
