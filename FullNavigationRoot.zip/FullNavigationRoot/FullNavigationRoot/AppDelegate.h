//
//  AppDelegate.h
//  FullNavigationRoot
//
//  Created by Sang Quý Lê on 6/9/13.
//  Copyright (c) 2013 lequysang.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CustomNavigationController.h"

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ViewController *viewController;

@property (strong, nonatomic) CustomNavigationController *navigationController;

@end
