//
//  ViewController.m
//  FullNavigationRoot
//
//  Created by Sang Quý Lê on 6/9/13.
//  Copyright (c) 2013 lequysang.com. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

-(NSUInteger)supportedInterfaceOrientations
{
    return UIInterfaceOrientationMaskAllButUpsideDown;
}

-(BOOL)shouldAutorotate
{
    return YES;
}



- (IBAction)goDetail:(id)sender {
    DetailViewController *detailVC = [[DetailViewController alloc] initWithNibName:@"DetailViewController" bundle:nil];
    
    [(AppDelegate *)[[UIApplication sharedApplication] delegate] performSelector:@selector(reloadRootNavigationController) withObject:nil afterDelay:0.0];
    
    [self.navigationController pushViewController:detailVC animated:NO];

    
}



@end
