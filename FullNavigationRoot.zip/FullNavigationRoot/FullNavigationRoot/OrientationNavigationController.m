//
//  OrientationNavigationController.m
//  eskeysiphone
//
//  Created by Sang Quý Lê on 4/23/13.
//  Copyright (c) 2013 lequysang.com. All rights reserved.
//

#import "OrientationNavigationController.h"

@interface OrientationNavigationController ()

@end

@implementation OrientationNavigationController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.supportedInterfaceOrientatoin = UIInterfaceOrientationMaskAllButUpsideDown;
        self.orientation = UIDeviceOrientationPortrait;
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (BOOL)shouldAutorotate
{
    return YES;
}

-(NSUInteger)supportedInterfaceOrientations

{
    return self.supportedInterfaceOrientatoin;
}

- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation
{
    return self.orientation;
}


@end
