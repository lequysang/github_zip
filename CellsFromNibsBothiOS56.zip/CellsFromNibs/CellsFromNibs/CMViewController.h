

#import <UIKit/UIKit.h>
#import "TableCell.h"

@interface CMViewController : UITableViewController<TableCellDelegate>

@property(nonatomic,strong) NSMutableArray *tableData;

@end
