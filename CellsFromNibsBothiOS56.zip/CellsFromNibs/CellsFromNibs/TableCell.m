//
//  TableCell.m
//  CellsFromNibs
//
//  Created by Sang Quý Lê on 3/12/13.
//  Copyright (c) 2013 Charismatic Megafauna Ltd. All rights reserved.
//

#import "TableCell.h"


@implementation TableCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (IBAction)changeBG:(UISwitch *)sender {
    [[self delegate] changeBackGGColor:self forON:sender.on];
}
@end
