//
//  ViewController.h
//  CollectionViewNonARC
//
//  Created by Sang Quý Lê on 3/9/13.
//  Copyright (c) 2013 lequysang. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIImageView+WebCache.h"
#import "SDImageCache.h"
#import "SDCell.h"

@interface ViewController : UIViewController
@property (retain, nonatomic) IBOutlet UICollectionView *collectionView;

@end
