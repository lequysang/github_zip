//
//  ViewController.m
//  CollectionViewNonARC
//
//  Created by Sang Quý Lê on 3/9/13.
//  Copyright (c) 2013 lequysang. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@property (strong , nonatomic) NSMutableArray *collectionData;

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    self.collectionData = [[[NSMutableArray alloc]
                           initWithObjects:
                           @"http://img827.imageshack.us/img827/9861/twitterkif.png",
                           @"http://img217.imageshack.us/img217/3563/facebookrs.png",
                           @"http://img543.imageshack.us/img543/934/youtubeno.png",
//                           @"http://img72.imageshack.us/img72/4080/bongdaso.png",
                           @"http://img593.imageshack.us/img593/2112/vietnamnet.png",
                           @"http://img546.imageshack.us/img546/5647/ngoisao.png",
                           @"http://img41.imageshack.us/img41/2415/laodong.png",
                           @"http://img521.imageshack.us/img521/6606/thanhnien.png",
                           @"http://img89.imageshack.us/img89/8572/dantri.png",
                           @"http://img507.imageshack.us/img507/7117/baomoi.png",
                           @"http://img255.imageshack.us/img255/6673/tuoitre.png",
                           @"http://img32.imageshack.us/img32/319/24h.png",
                           @"http://img145.imageshack.us/img145/4453/vnexpress.png",
                           nil] autorelease];

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
    [_collectionView release];
    [super dealloc];
}

////UICollectionViewDataSource
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return [self.collectionData count];;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)cv cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    SDCell *cell = (SDCell *)[cv dequeueReusableCellWithReuseIdentifier:@"SDCell" forIndexPath:indexPath];
    
    cell.cellImageView.image = [UIImage imageNamed:@"placeholder.png"];
    
    NSURL *cellImageURL = [NSURL URLWithString:[NSString stringWithFormat:@"%@",[self.collectionData objectAtIndex:indexPath.row]]];
    [cell.cellIndicator startAnimating];

    SDWebImageManager *manager = [SDWebImageManager sharedManager];
    [manager downloadWithURL:cellImageURL
                    delegate:self
                     options:0
    success:^(UIImage *image, BOOL cached)
    { 
        cell.cellImageView.image = image;
        [cell.cellIndicator stopAnimating];
    } failure:nil];
        
    
    return cell;
    
}

@end
