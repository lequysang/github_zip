//
//  SDCell.m
//  CollectionViewNonARC
//
//  Created by Sang Quý Lê on 3/9/13.
//  Copyright (c) 2013 lequysang. All rights reserved.
//

#import "SDCell.h"

@implementation SDCell

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

- (void)dealloc {
    [_cellImageView release];
    [_cellIndicator release];
    [super dealloc];
}
@end
