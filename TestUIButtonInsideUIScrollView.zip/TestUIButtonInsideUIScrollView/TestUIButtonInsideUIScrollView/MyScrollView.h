//
//  MyScrollView.h
//  TestUIButtonInsideUIScrollView
//
//  Created by Sang Quý Lê on 3/19/13.
//  Copyright (c) 2013 lequysang. All rights reserved.
//

#import <UIKit/UIKit.h>
@class MyScrollView;

@protocol MyScrollViewDelegate<UIScrollViewDelegate>
-(void)clickButton:(UIButton *)aBut atPostition:(CGRect)butFrame;
@end

@interface MyScrollView : UIScrollView{
    NSMutableArray *containerArray;
    NSMutableArray *titleArray;

}
@property (nonatomic,weak) id<MyScrollViewDelegate> delegate;

@end
