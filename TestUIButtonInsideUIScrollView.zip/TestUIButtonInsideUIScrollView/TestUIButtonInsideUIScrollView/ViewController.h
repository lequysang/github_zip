//
//  ViewController.h
//  TestUIButtonInsideUIScrollView
//
//  Created by Sang Quý Lê on 3/19/13.
//  Copyright (c) 2013 lequysang. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyScrollView.h"

@interface ViewController : UIViewController<MyScrollViewDelegate>
@property (weak, nonatomic) IBOutlet MyScrollView *scrollView;

@end
