//
//  MyScrollView.m
//  TestUIButtonInsideUIScrollView
//
//  Created by Sang Quý Lê on 3/19/13.
//  Copyright (c) 2013 lequysang. All rights reserved.
//

#import "MyScrollView.h"

@implementation MyScrollView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}
-(void)awakeFromNib{
    
    [self setBackgroundColor:[UIColor clearColor]];
    
    titleArray = [NSMutableArray arrayWithObjects:
                  @"1",
                  @"2",
                  @"3",
                  @"4",
                  @"5",
                  @"6",
                  @"7",
//                  @"8",
//                  @"9",
//                  @"10",
                  nil];
    
    containerArray = [NSMutableArray array];
    [self updateContainer];
    
    [self setContentSize:CGSizeMake([titleArray count]*110, 100)];
}

-(void)updateContainer{
    for (NSInteger i = 0;i < [titleArray count]; i++) {
        UIButton *aBut = [[UIButton alloc] initWithFrame:CGRectMake(10 +110*i, 10, 100, 100)];
//        aBut.
        [aBut setImage:[UIImage imageNamed:[NSString stringWithFormat:@"flower%@.png",[titleArray objectAtIndex:i]]] forState:UIControlStateNormal];

        [aBut setTitle:[titleArray objectAtIndex:i] forState:UIControlStateNormal];
        
        [aBut setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
        
        [aBut addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
        
        [self addSubview:aBut];
    }
}

-(IBAction)clickButton:(UIButton *)sender{
    [[self delegate] clickButton:sender atPostition:sender.frame];
}

@end
