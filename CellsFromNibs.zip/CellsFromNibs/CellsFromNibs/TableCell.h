//
//  TableCell.h
//  CellsFromNibs
//
//  Created by Sang Quý Lê on 3/12/13.
//  Copyright (c) 2013 Charismatic Megafauna Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>
@class TableCell;

@protocol TableCellDelegate

-(void)changeBackGGColor:(TableCell *)cell forON:(BOOL)isON;

@end

@interface TableCell : UITableViewCell
@property(nonatomic,weak) id<TableCellDelegate> delegate;
- (IBAction)changeBG:(UISwitch *)sender;

@end
