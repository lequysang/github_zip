//
//  ViewController.m
//  TestTapOnWeb
//
//  Created by Sang Quý Lê on 3/30/13.
//  Copyright (c) 2013 lequysang. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    NSString *webLink = @"http://stackoverflow.com/questions/15694226/crash-when-removeobserver-for-an-integer-property";
    [self.webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:webLink]]];

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType{
    NSURL *url = request.URL;
    NSString *urlString = url.absoluteString;
    NSLog(@"%@",urlString);
    
    if ([urlString isEqualToString:@"https://github.com/lequysang/github_zip/blob/master/CustomViewKVO.zip"]) {
        WebViewController *webVC = [[WebViewController alloc] initWithNibName:@"WebViewController" bundle:nil];
        webVC.webLink = urlString;
        [self.navigationController pushViewController:webVC animated:YES];
    }
    
    return YES;
    
}

- (void)webViewDidStartLoad:(UIWebView *)webView{
    
}

- (void)webViewDidFinishLoad:(UIWebView *)webView{
    
}
- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error{
    
}


@end
