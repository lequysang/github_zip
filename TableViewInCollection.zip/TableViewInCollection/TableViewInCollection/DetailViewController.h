//
//  DetailViewController.h
//  TableViewInCollection
//
//  Created by Sang Quý Lê on 3/4/13.
//  Copyright (c) 2013 lequysang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailViewController : UIViewController
@property (weak, nonatomic) IBOutlet UILabel *label;

@end
