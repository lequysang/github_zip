//
//  ViewController.h
//  TableViewInCollection
//
//  Created by Sang Quý Lê on 3/4/13.
//  Copyright (c) 2013 lequysang. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CollectionCell.h"
#import "DetailViewController.h"

@interface ViewController : UIViewController<UICollectionViewDataSource,ColectionCellDelegate>

@end
