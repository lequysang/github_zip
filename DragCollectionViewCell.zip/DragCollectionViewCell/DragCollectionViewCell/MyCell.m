//
//  MyCell.m
//  DragCollectionViewCell
//
//  Created by Quy Sang Le on 2/12/13.
//  Copyright (c) 2013 Quy Sang Le. All rights reserved.
//

#import "MyCell.h"

@implementation MyCell

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
    }
    return self;
}


@end
