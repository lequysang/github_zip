//
//  MyCell.m
//  DragCollectionViewCell
//
//  Created by Quy Sang Le on 2/12/13.
//  Copyright (c) 2013 Quy Sang Le. All rights reserved.
//

#import "MyCell.h"

@implementation MyCell

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
    }
    return self;
}

- (void)awakeFromNib{
    [self addGestureRecognizersToView:self];
}

- (void)addGestureRecognizersToView:(UIView *)viewWithGestures
{
    UILongPressGestureRecognizer *longPressGesture = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(handleLongPressGesture:)];
    [viewWithGestures addGestureRecognizer:longPressGesture];
}

-(void)handleLongPressGesture:(UILongPressGestureRecognizer *)longPressGesture{
    MyCell *cell = (MyCell *)longPressGesture.view;
    //Prepare for edit-moving
    if ([longPressGesture state] == UIGestureRecognizerStateBegan) {
        [UIView animateWithDuration:0.25 animations:^(void){
            [cell setTransform:CGAffineTransformMakeScale(1.2, 1.2)];
            [cell setAlpha:0.8];
        } completion:^(BOOL finished) {
        }];
    }
    //Drag
    if ([longPressGesture state] == UIGestureRecognizerStateChanged) {
        cell.center = [longPressGesture locationInView:cell.superview];
        [self.delegate cellIsDragging:self];
    }
    //DragEnd or Cancel
    if( ([longPressGesture state] == UIGestureRecognizerStateEnded) || ([longPressGesture state] == UIGestureRecognizerStateCancelled)  ){
        [UIView animateWithDuration:0.7 animations:^(void){
            [cell setTransform:CGAffineTransformMakeScale(1.0, 1.0)];
            [cell setAlpha:1.0];
            
        } completion:^(BOOL finished) {
        }];
    }
    
}


@end
