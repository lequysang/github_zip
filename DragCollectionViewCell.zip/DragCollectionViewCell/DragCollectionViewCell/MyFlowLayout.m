//
//  MyFlowLayout.m
//  DragCollectionViewCell
//
//  Created by Sang Quý Lê on 2/26/13.
//  Copyright (c) 2013 Quy Sang Le. All rights reserved.
//

#import "MyFlowLayout.h"

@implementation MyFlowLayout

- (CGSize)collectionViewContentSize
{
    NSInteger itemCount = [self.collectionView numberOfItemsInSection:0];
    NSInteger pages = ceil(itemCount / 4.0);
    
    return CGSizeMake(300 * pages, self.collectionView.frame.size.height);
}

- (id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super init];
    if (self) {
        [self setup];
    }
    
    return self;
}

- (void)setup
{
    self.itemSize = CGSizeMake(57.0f, 57.0f);
    self.minimumLineSpacing = 18;
    self.sectionInset = UIEdgeInsetsMake(0.f, 0.f, 0.0f, 0.f);
    [self setScrollDirection:UICollectionViewScrollDirectionHorizontal];
}

@end
