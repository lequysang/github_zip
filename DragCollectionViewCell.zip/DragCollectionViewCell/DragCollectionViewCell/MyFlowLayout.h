//
//  MyFlowLayout.h
//  DragCollectionViewCell
//
//  Created by Sang Quý Lê on 2/26/13.
//  Copyright (c) 2013 Quy Sang Le. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyFlowLayout : UICollectionViewFlowLayout

@end
