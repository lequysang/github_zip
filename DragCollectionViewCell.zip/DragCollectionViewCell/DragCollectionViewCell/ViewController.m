//
//  ViewController.m
//  DragCollectionViewCell
//
//  Created by Quy Sang Le on 2/12/13.
//  Copyright (c) 2013 Quy Sang Le. All rights reserved.
//

#import "ViewController.h"

@interface ViewController (){
    NSInteger setSmallSize;
    NSInteger scrolltime;
    
    CGRect currentCollectionFrame;
}
@property (nonatomic,strong) NSMutableArray *collectionData;
@property (nonatomic,strong) NSMutableArray *allCells;
@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    scrolltime = 0;
    setSmallSize = -1;
    self.collectionData = [[NSMutableArray alloc] initWithObjects:
                           @"0",
                           @"1",
                           @"2",
                           @"3",
                           @"4",
                           @"5",
//                           @"6",
//                           @"7",
//                           @"8",
//                           @"9",
                           nil];

}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    [collectionView setContentSize:CGSizeMake(640, 100)];

    return [self.collectionData count];
}

- (MyCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    [collectionView setContentSize:CGSizeMake(640, 100)];

    MyCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"MYCELL" forIndexPath:indexPath];
    cell.label.text = [self.collectionData objectAtIndex:indexPath.row];
    return cell;
}



@end
