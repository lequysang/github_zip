//
//  ViewController.m
//  DragCollectionViewCell
//
//  Created by Quy Sang Le on 2/12/13.
//  Copyright (c) 2013 Quy Sang Le. All rights reserved.
//

#import "ViewController.h"

@interface ViewController (){
    NSInteger setSmallSize;
    NSInteger scrolltime;
    
    CGRect currentCollectionFrame;
}
@property (nonatomic,strong) NSMutableArray *collectionData;
@property (nonatomic,strong) NSMutableArray *allCells;
@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    scrolltime = 0;
    setSmallSize = -1;
    self.collectionData = [[NSMutableArray alloc] initWithObjects:
                           @"0",
                           @"1",
                           @"2",
                           @"3",
                           @"4",
                           @"5",
//                           @"6",
//                           @"7",
//                           @"8",
//                           @"9",
                           nil];
//    NSLog(@"Current Frame:%f,%f,%f,%f",self.collectionView.frame.origin.x,self.collectionView.frame.origin.y,self.collectionView.frame.size.width,self.collectionView.frame.size.height);
}
//-(void)viewDidAppear:(BOOL)animated{
////    NSLog(@"Current Frame:%0f,%0f,%0f,%0f",self.collectionView.frame.origin.x,self.collectionView.frame.origin.y,self.collectionView.frame.size.width,self.collectionView.frame.size.height);
////    currentCollectionFrame = self.collectionView.frame;
////    [self.collectionView setContentSize:CGSizeMake(640, 100)];
// }
//-(void)viewDidLayoutSubviews{
   
//}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    [collectionView setContentSize:CGSizeMake(640, 100)];

    return [self.collectionData count];
}

- (MyCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    [collectionView setContentSize:CGSizeMake(640, 100)];

    MyCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"MYCELL" forIndexPath:indexPath];
    cell.label.text = [self.collectionData objectAtIndex:indexPath.row];
    cell.delegate = self;
    return cell;
}

-(void)cellIsDragging:(MyCell *)cell{
    if (cell.center.x > self.collectionView.frame.size.width - 30) {
        NSLog(@"cell go next page");
    }
    NSArray *cells = [self.collectionView visibleCells];
    
    for (MyCell *aCell in cells) {
        if (CGRectContainsPoint(aCell.frame, cell.center)&&(aCell != cell)) {
            NSLog(@"Drag to cell : %@",aCell.label.text);
        }
    }
   
}

//- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate{
//    NSArray *cells = [self.collectionView visibleCells];
//    for (MyCell *aCell in cells) {
//            NSLog(@"Cell %@ - frame:(%0f,%0f,%0f,%0f)",aCell.label.text,aCell.frame.origin.x,aCell.frame.origin.y,aCell.frame.size.width,aCell.frame.size.height);
//    }
//
////    CGFloat pageWidth = scrollView.frame.size.width;
////    int page = floor((scrollView.contentOffset.x - pageWidth / 2) / pageWidth) + 1;
////    currentCollectionFrame.origin.x = pageWidth * page;
////    
////    NSLog(@"Current Frame:%0f,%0f,%0f,%0f",currentCollectionFrame.origin.x,currentCollectionFrame.origin.y,currentCollectionFrame.size.width,currentCollectionFrame.size.height);
//}

//- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
//    NSArray *cells = [self.collectionView visibleCells];
//    for (MyCell *aCell in cells) {
//        NSLog(@"Cell %@ - frame:(%0f,%0f,%0f,%0f)",aCell.label.text,aCell.frame.origin.x,aCell.frame.origin.y,aCell.frame.size.width,aCell.frame.size.height);
//    }
//    
//    CGFloat pageWidth = scrollView.frame.size.width;
//    int page = floor((scrollView.contentOffset.x - pageWidth / 2) / pageWidth) + 1;
//    currentCollectionFrame.origin.x = self.collectionView.frame.origin.x + pageWidth * page;
//    NSLog(@"Current Frame:%0f,%0f,%0f,%0f",currentCollectionFrame.origin.x,currentCollectionFrame.origin.y,currentCollectionFrame.size.width,currentCollectionFrame.size.height);
//
//}
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    NSLog(@"indexPath: %@",indexPath);
//    NSArray *cells = collectionView.subviews;
//    NSLog(@"All Cell: %@",cells);
//self.allCells = [[NSMutableArray alloc] init];
//
//for (NSInteger aRow = 0; aRow < [self.collectionData count];aRow ++ ) {
//    MyCell *cell = (MyCell *)[collectionView cellForItemAtIndexPath:indexPath.];
//    [self.allCells addObject:cell];
//}
//    NSLog(@"%@",self.allCells);
}





@end
