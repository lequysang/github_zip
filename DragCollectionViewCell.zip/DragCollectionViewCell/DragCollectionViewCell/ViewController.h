//
//  ViewController.h
//  DragCollectionViewCell
//
//  Created by Quy Sang Le on 2/12/13.
//  Copyright (c) 2013 Quy Sang Le. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyCell.h"

@interface ViewController : UIViewController<UICollectionViewDataSource,UICollectionViewDelegate,MyCellDelegate>
@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;

- (IBAction)changeSize:(UIButton *)sender;


@end
