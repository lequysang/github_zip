//
//  ViewController.h
//  CustomViewKVO
//
//  Created by Sang Quý Lê on 3/29/13.
//  Copyright (c) 2013 lequysang. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CustomView.h"

@interface ViewController : UIViewController
- (IBAction)changeOutside:(id)sender;

@end
