//
//  ViewController.m
//  CustomViewKVO
//
//  Created by Sang Quý Lê on 3/29/13.
//  Copyright (c) 2013 lequysang. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property(strong ,nonatomic) CustomView *customView;
@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.customView = [[CustomView alloc] init];
    NSArray *nibs = [[NSBundle mainBundle] loadNibNamed:@"CustomView" owner:self options:nil];
    self.customView = [nibs objectAtIndex:0];
    self.customView.center = self.view.center;
    [self.view addSubview:self.customView];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)changeOutside:(id)sender {
    self.customView.inputStateControl ++;
}
- (void)viewDidUnload {
    [self setCustomView:nil];
    [super viewDidUnload];
}
@end
