//
//  AppDelegate.h
//  fullTabBaseApp
//
//  Created by Sang Quý Lê on 6/8/13.
//  Copyright (c) 2013 lequysang.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CustomTabBarController.h"
#import "CustomNavigationController.h"
#import "NextOfThirdViewController.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate, UITabBarControllerDelegate,UINavigationControllerDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) CustomTabBarController *tabBarController;

//@property (strong, nonatomic) ThirdNavigationController *thirdNavigationController;

@end
