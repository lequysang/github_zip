//
//  ViewController.h
//  MyCollectionView
//
//  Created by Quy Sang Le on 11/5/12.
//  Copyright (c) 2012 Quy Sang Le. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Cell.h"

@interface ViewController : UIViewController<UICollectionViewDataSource, UICollectionViewDelegate>

@end
