//
//  ViewController.m
//  TestDAAttributeString
//
//  Created by Sang Quý Lê on 4/10/13.
//  Copyright (c) 2013 lequysang. All rights reserved.
//

#import "ViewController.h"
#import "DAAttributedLabel.h"
#import "DAAttributedStringFormatter.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    DAAttributedStringFormatter* formatter = [[DAAttributedStringFormatter alloc] init];
	formatter.defaultFontFamily = @"TimesNewRoman";
	formatter.defaultColor = [UIColor blueColor];
	formatter.fontFamilies = @[ @"Courier", @"Arial", @"Georgia" ];
	formatter.colors = @[ [UIColor blackColor], [UIColor redColor], [UIColor greenColor] ];
	
	DAAttributedLabel* label1 = [[DAAttributedLabel alloc] initWithFrame:CGRectMake(30.0f, 30.0f, 260.0f, 24.0f)];
	label1.backgroundColor = [UIColor colorWithRed:0.9f green:0.9f blue:1.0f alpha:1.0f];
	label1.text = (id)[formatter formatString:@"Normal %BBold%b %IItalic%i %B%IBold-Italic%i%b"];
	[self.view addSubview:label1];
	
	DAAttributedLabel* label2 = [[DAAttributedLabel alloc] initWithFrame:CGRectMake(30.0f, 80.0f, 260.0f, 24.0f)];
	label2.backgroundColor = [UIColor colorWithRed:0.9f green:0.9f blue:1.0f alpha:1.0f];
//	label2.text = (id)[formatter formatString:@"This is some long text with colors %0CBLACK%c and %1CRED%c and %2CGREEN%c, background colors of %1DRED%d and %2DGREEN%d, plus fonts %0FCOURIER%f and %1FArial%f and %2FGeorgia%f, plus %40S%2DBIGGER%d%s and %8SSMALLER%s text."];
////TEXT COLOR
    //%colorPostionC TEXT %c//
//    label2.text = (id)[formatter formatString:@"TEST colors %0CBLACK%c and %1CRED%c and %2CGREEN%c text"];
////BGCOLOR
//    label2.text = (id)[formatter formatString:@"TEST  background colors of %1DRED%d and %2DGREEN%d "];
    
///FONT
//    label2.text = (id)[formatter formatString:@"TEST fonts %0FCOURIER%f and %1FArial%f and %2FGeorgia%f text"];

// SIZE
//    label2.text = (id)[formatter formatString:@"TEST Size %30S%2DBIGGER%d%s and %10SSMALLER%s text."];
    // SIZE and Color
//    label2.text = (id)[formatter formatString:@"TEST Size %30S%2DBIGGER%d%s and %10SSMALLER%s text."];
    
    label2.text = (id)[formatter formatString:@"%30S TEST colors %0CBLACK%c and %1CRED%c and %2CGREEN%c text %s"];


	[label2 setPreferredHeight];
	[self.view addSubview:label2];
    
//	DAAttributedLabel* label3 = [[DAAttributedLabel alloc] initWithFrame:CGRectMake(30.0f, label2.frame.origin.y + label2.frame.size.height + 30.0f, 260.0f, 24.0f)];
//	label3.backgroundColor = [UIColor colorWithRed:0.9f green:0.9f blue:1.0f alpha:1.0f];
//	NSAttributedString* attrStr = [formatter formatString:@"This is %B%LClickable%l%b text.  You %B%1U%Lcan also%l%u%b click on %B%LThis longer text.%l%b"];
//	label3.text = attrStr;
//	[label3 setPreferredHeight];
////	label3.delegate = self;
//	[self.view addSubview:label3];

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
